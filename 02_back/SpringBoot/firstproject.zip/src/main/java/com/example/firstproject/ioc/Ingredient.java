package com.example.firstproject.ioc;

public class Ingredient {
    private String name;

    public String getName() {
        return name;
    }

    public Ingredient(String name) {
        this.name = name;
    }
}
